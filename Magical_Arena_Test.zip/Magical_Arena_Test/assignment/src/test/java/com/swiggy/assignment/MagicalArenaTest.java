package com.swiggy.assignment;

import static org.junit.Assert.assertFalse;
import org.junit.Test;

public class MagicalArenaTest {
    @Test
    public void testFight() {
        player playerA = new player(50, 5, 10);
        player playerB = new player(100, 10, 5);

        magicalArena arena = new magicalArena(playerA, playerB);
        arena.fight();

        assertFalse(playerA.isAlive() && playerB.isAlive()); 
    }
}
